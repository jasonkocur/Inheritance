//UTA inheritance 4/18/2019
#include "clock_time.cpp"
#define MAX_CLOCK_NAME 64
#include <vector>
#include<cstring>
#define RUN_TIME 604800 // seconds in one week
enum CLOCK_TYPE{Sundial, Atomic, Cuckoo, Grandfather, Wrist};


class Clock
{
	public:
		Clock(CLOCK_TYPE const type, ClockTime const& initialTime, double const driftPerSecond, char const * const name)
		{
			clockTime_.setTime(initialTime);
			type_ = Sundial;
			driftPerSecond_ = driftPerSecond;
			strcpy(name_,name);
		}
	protected:
		ClockTime clockTime_;
	
	private:
		CLOCK_TYPE type_;
		double driftPerSecond_;
		char name_[MAX_CLOCK_NAME];
	
	public:
		virtual void reset() = 0; //pure virtual function
		virtual void tick() = 0; //pure virtual function
		virtual void displayTime() const = 0; //pure virtual function
		char const * const name() const
		{
			return name_;
		};
		double const driftPerSecond() const
		{
			return driftPerSecond_;
		};
		
};

class NaturalClock : public Clock // inheritance
{
	public:
		NaturalClock(CLOCK_TYPE const type, 
		ClockTime const& initialTime, 
		double const driftPerSecond, 
		char const * const name) : Clock(type, initialTime, driftPerSecond, name){}//empty constructor
		virtual void reset() = 0; //pure virtual function
		virtual void tick() = 0; //pure virtual function
		virtual void displayTime() const = 0; //pure virtual function		
};

class MechanicalClock : public Clock // inheritance
{
	public:
		MechanicalClock(CLOCK_TYPE const type, 
		ClockTime const& initialTime, 
		double const driftPerSecond, 
		char const * const name) : Clock(type, initialTime, driftPerSecond, name){}//empty constructor
		virtual void reset() = 0; //pure virtual function
		virtual void tick() = 0; //pure virtual function
		virtual void displayTime() const = 0; //pure virtual function		
};

class DigitalClock : public Clock // inheritance
{
	public:
		DigitalClock(CLOCK_TYPE const type, 
		ClockTime const& initialTime, 
		double const driftPerSecond, 
		char const * const name) : Clock(type, initialTime, driftPerSecond, name){}//empty constructor
		virtual void reset() = 0; //pure virtual function
		virtual void tick() = 0; //pure virtual function
		virtual void displayTime() const = 0; //pure virtual function		
};

class QuantumClock : public Clock // inheritance
{
	public:
		QuantumClock(CLOCK_TYPE const type, 
		ClockTime const& initialTime, 
		double const driftPerSecond, 
		char const * const name) : Clock(type, initialTime, driftPerSecond, name){}//empty constructor
		virtual void reset() = 0; //pure virtual function
		virtual void tick() = 0; //pure virtual function
		virtual void displayTime() const = 0; //pure virtual function		
};

class SundialClock : public NaturalClock // inheritance
{
	public:
		SundialClock(CLOCK_TYPE const type, 
		ClockTime const& initialTime, 
		double const driftPerSecond, 
		char const * const name) : NaturalClock(type, initialTime, driftPerSecond, name){}//empty constructor
		void reset()//virtual overload the child can overload the functions of the parent
		{
			clockTime_.reset();
		}
		void tick()
		{
			clockTime_.increment();
		}
		void displayTime() const
		{
			cout <<name()<< " Clock\t\t time["; 
			clockTime_.display();
			cout <<"] - total drift = ";
			//calculate total drift
			cout << (clockTime_.deltaTime() * driftPerSecond());
			cout << " seconds";
		}		
};

class CuckooClock : public MechanicalClock // inheritance
{
	public:
		CuckooClock(CLOCK_TYPE const type, 
		ClockTime const& initialTime, 
		double const driftPerSecond, 
		char const * const name) : MechanicalClock(type, initialTime, driftPerSecond, name){}//empty constructor
		void reset()//virtual overload the child can overload the functions of the parent
		{
			clockTime_.reset();
		}
		void tick()
		{
			clockTime_.increment();
		}
		void displayTime() const
		{
			cout <<name()<< " Clock\t\t time["; 
			clockTime_.display();
			cout <<"] - total drift = ";
			//calculate total drift
			cout << (clockTime_.deltaTime() * driftPerSecond());
			cout << " seconds";
		}		
};

class GrandfatherClock : public MechanicalClock // inheritance
{
	public:
		GrandfatherClock(CLOCK_TYPE const type, 
		ClockTime const& initialTime, 
		double const driftPerSecond, 
		char const * const name) : MechanicalClock(type, initialTime, driftPerSecond, name){}//empty constructor
		void reset()//virtual overload the child can overload the functions of the parent
		{
			clockTime_.reset();
		}
		void tick()
		{
			clockTime_.increment();
		}
		void displayTime() const
		{
			cout <<name()<< " Clock\t time["; 
			clockTime_.display();
			cout <<"] - total drift = ";
			//calculate total drift
			cout << (clockTime_.deltaTime() * driftPerSecond());
			cout << " seconds";
		}		
};

class WristClock : public DigitalClock // inheritance
{
	public:
		WristClock(CLOCK_TYPE const type, 
		ClockTime const& initialTime, 
		double const driftPerSecond, 
		char const * const name) : DigitalClock(type, initialTime, driftPerSecond, name){}//empty constructor
		void reset()//virtual overload the child can overload the functions of the parent
		{
			clockTime_.reset();
		}
		void tick()
		{
			clockTime_.increment();
		}
		void displayTime() const
		{
			cout <<name()<< " Clock\t\t time["; 
			clockTime_.display();
			cout <<"] - total drift = ";
			//calculate total drift
			cout << (clockTime_.deltaTime() * driftPerSecond());
			cout << " seconds";
		}		
};

class AtomicClock : public QuantumClock // inheritance
{
	public:
		AtomicClock(CLOCK_TYPE const type, 
		ClockTime const& initialTime, 
		double const driftPerSecond, 
		char const * const name) : QuantumClock(type, initialTime, driftPerSecond, name){}//empty constructor
		void reset()//virtual overload the child can overload the functions of the parent
		{
			clockTime_.reset();
		}
		void tick()
		{
			clockTime_.increment();
		}
		void displayTime() const
		{
			cout <<name()<< " Clock\t\t time["; 
			clockTime_.display();
			cout <<"] - total drift = ";
			//calculate total drift
			cout << (clockTime_.deltaTime() * driftPerSecond());
			cout << " seconds";
		}		
};

int main()
{
	vector<Clock*> clocks_;
	ClockTime ct;
	ct.setTime(0,0,0,1);
	
	cout << "Reported clock times after resetting:" << endl;
	cout << "=====================================" << endl;
	SundialClock sd(Sundial, ct, 0.0, "Sundial");
	sd.displayTime();
	cout << endl;
	CuckooClock cc(Cuckoo, ct, 0.000694444, "Cuckoo");
	cc.displayTime();
	cout << endl;
	GrandfatherClock gc(Grandfather, ct, 0.000347222, "Grandfather");
	gc.displayTime();
	cout << endl;
	WristClock wc(Wrist, ct, 0.000034722, "Wrist");
	wc.displayTime();
	cout << endl;
	AtomicClock ac(Atomic, ct, 0.0, "Atomic");
	ac.displayTime();
	
	for(int c=0; c<604800; c++)
	{
		sd.tick();
		cc.tick();
		gc.tick();
		wc.tick();
		ac.tick();
	}
	cout << endl;
	cout << endl;
	cout << "Running the clocks for one (1) week..." << endl;
	cout << "" << endl;
	cout << "Reported clock times after running:" << endl;
	cout << "=====================================" << endl;
	sd.displayTime();
	cout << endl;
	cc.displayTime();
	cout << endl;
	gc.displayTime();
	cout << endl;
	wc.displayTime();
	cout << endl;
	ac.displayTime();
	
	return 0;
}

